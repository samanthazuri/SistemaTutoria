<?php
	session_start();

	$opcion = $_GET['opc'];

	$_SESSION['J3Opc'] = $opcion;



?>