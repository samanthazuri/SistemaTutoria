<?php

	session_start();

	$tipoJefe = $_SESSION['tipoJefe'];
	

	echo($tipoJefe);



?>